



import java.awt.*;
import javax.swing.*;
public class CampusEventRegistration {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Campus Event Registration");
        frame.setSize(500, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));

        JLabel lblName = new JLabel("Participant Name: ");
        JTextField txtName = new JTextField
        (30);
        JLabel lblAge = new JLabel("Age: ");
        JTextField txtAge = new JTextField
        (10);
        JLabel lblCollege = new JLabel("College/Department: ");
        JTextField txtCollege = new JTextField
        (30);


        JLabel lblCategory = new JLabel("Event Category: ");
        String[] eventcategory = {
            "Select Event", "Programming Competition", "Web Design Challenge", "Cybersecurity Seminar", "AI and Emerging Technologies" , "IT Quiz Bowl"
        };
        JComboBox<String> cmbCategory = new JComboBox<>(eventcategory);

        JLabel lblMultiple = new JLabel("Attendance Type: ");
        JRadioButton a = new JRadioButton("Studennt Participation");
        JRadioButton b = new JRadioButton("Student Audience");
        JRadioButton c = new JRadioButton("Faculty/Staff");
       

        ButtonGroup multiplechoice = new ButtonGroup();
        multiplechoice.add(a);
        multiplechoice.add(b);
        multiplechoice.add(c);
    

        JLabel lblAttend = new JLabel("Worshops to Attend: ");
        JCheckBox f1 = new JCheckBox("Java Programming");
        JCheckBox f2 = new JCheckBox("Web Development");
        JCheckBox f3 = new JCheckBox("Cybersecurity");
        JCheckBox f4 = new JCheckBox("Artificial Intelligence");
        JCheckBox f5 = new JCheckBox("Database Managemnet");

        JLabel lblNotes = new JLabel("Special Request or Notes");
        JTextArea txtNotes = new JTextArea(5, 30);

        txtNotes.setLineWrap(true);
        txtNotes.setWrapStyleWord(true);

        JButton btnRegister = new JButton("Register");
        JButton btnClear = new JButton("Clear");
        

        frame.add(lblName);
        frame.add(txtName);
        frame.add(lblCollege);
        frame.add(txtCollege);
        frame.add(lblAge);
        frame.add(txtAge);
        frame.add(lblCategory);
        frame.add(cmbCategory);
        frame.add(lblMultiple);
        frame.add(a);
        frame.add(b);
        frame.add(c);
        frame.add(lblAttend);
        frame.add(f1);
        frame.add(f2);
        frame.add(f3);
        frame.add(f4);
        frame.add(f5);
        frame.add(lblNotes);
        frame.add(txtNotes);
        frame.add(btnRegister);
        frame.add(btnClear);

        btnRegister.addActionListener(e -> {

            String name = txtName.getText().trim();
            String ageText = txtAge.getText().trim();
            String college = txtCollege.getText().trim();
            if (name.isEmpty()) {
                    JOptionPane.showMessageDialog( frame, "Participant Name is required.","Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );

                txtName.requestFocus();
                return;
            }

            if (ageText.isEmpty()) {
                    JOptionPane.showMessageDialog( frame, "Age is required.", "Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );

                txtAge.requestFocus();
                return;
            }

            int age;
            try {
                age = Integer.parseInt(ageText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog( frame, "Age must be a valid whole number.","Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );

                txtAge.requestFocus();
                return;
            }

            if (age <= 0) {
                JOptionPane.showMessageDialog(
                        frame, "Age must be greater than zero.", "Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );

                txtAge.requestFocus();
                return;
            }

            if (college.isEmpty()) {
                JOptionPane.showMessageDialog( frame, "College/Department is required.","Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );

                txtCollege.requestFocus();
                return;
            }

            if (cmbCategory.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog( frame, "Please select an Event Category.", "Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }


            String eventcategories = cmbCategory.getSelectedItem().toString();
            String choice = "";
            if (a.isSelected()) {choice = "Student Participant";
            } else if (b.isSelected()) {
                 choice = "Student Audience";
            } else if (c.isSelected()) {
                choice = "Faculty/Staff";
            } else {
                JOptionPane.showMessageDialog(
                        frame, "Please select an Attendance Type.","Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }


            
            String menu = "";
            if (f1.isSelected()) {
                menu += "Java Programming, ";
            } if (f2.isSelected()) {
                menu += "Web Development, ";
            } if (f3.isSelected()) {
                menu += "Cybersecurity, ";
            } if (f4.isSelected()) {
                menu += "Artificial Intelligence, ";
            } if (f5.isSelected()) {
                menu += "Database Management, ";
            } if (!menu.isEmpty()) {
                menu = menu.substring(0, menu.length() - 2);
            } else {
                menu = "None";
            }

            String notes = txtNotes.getText().trim();
            if (notes.isEmpty()) {
                notes = "None";
            }

            String message =
                    "REGISTERED\n\n" + "Participant Name: " + name + "\n" + "Age: " + age + "\n" + "College/Department: " + college + "\n" + "Event Category: " + eventcategories + "\n" + "Attendance Type: " + choice + "\n" + "Workshops to Attend: " + menu + "\n" + "Special Request/Notes: " + notes;

            JOptionPane.showMessageDialog(
                    frame, message, "Registration Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

        });


        btnClear.addActionListener(e -> {

            txtName.setText("");
            txtAge.setText("");
            txtCollege.setText("");
            cmbCategory.setSelectedIndex(0);
            multiplechoice.clearSelection();
            f1.setSelected(false);
            f2.setSelected(false);
            f3.setSelected(false);
            f4.setSelected(false);
            f5.setSelected(false);
            txtNotes.setText("");
            txtName.requestFocus();
        });


        frame.setVisible(true);
        

    }



}